import { useEffect, useState } from 'react';
import { signIn, signOut, useSession } from 'next-auth/react';
import { useRouter } from 'next/router';

export default function AdminIndex() {
  const { data: session } = useSession();
  const [events, setEvents] = useState<any[] | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function load() {
    if (!session) return;
    setLoading(true);
    const res = await fetch('/api/admin/events');
    if (res.status === 401) {
      // not authorized
      setLoading(false);
      return;
    }
    const data = await res.json();
    setEvents(data);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, [session]);

  async function toggle(id: number) {
    const res = await fetch(`/api/admin/events/${id}/toggle-finished`, {
      method: 'POST'
    });
    if (res.ok) {
      const updated = await res.json();
      setEvents((prev) => prev?.map((e) => (e.id === updated.id ? updated : e)));
    }
  }

  if (!session) {
    return (
      <div className="container">
        <h1>Admin</h1>
        <div className="card">
          <p>Not signed in.</p>
          <button className="button" onClick={() => signIn()}>Sign in</button>
          <p className="small">If you have no admin account, create one at <a href="/admin/register">/admin/register</a> (protected by ADMIN_SECRET).</p>
        </div>
      </div>
    );
  }

  // check role
  // @ts-ignore
  if (session.user?.role !== 'ADMIN') {
    return (
      <div className="container">
        <h1>Admin</h1>
        <div className="card">
          <p>Unauthorized. Your account is not an admin.</p>
          <button className="button" onClick={() => signOut()}>Sign out</button>
        </div>
      </div>
    );
  }

  if (loading) return <div className="container">Loading...</div>;
  if (!events) return <div className="container">No events</div>;

  return (
    <div className="container">
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h1>Admin — Events</h1>
        <div>
          <span style={{marginRight:12}}>Signed in as {(session.user?.email) || ''}</span>
          <button className="button" onClick={() => signOut()}>Sign out</button>
        </div>
      </div>

      {events.map((e) => (
        <div key={e.id} className="card">
          <h2>{e.title}</h2>
          <p>{new Date(e.startAt).toLocaleString()} — {new Date(e.endAt).toLocaleString()}</p>
          <p>Venue: {e.venue?.name}</p>
          <p>Status: {e.finished ? 'Finished' : 'Not Finished'}</p>
          <button className="button" onClick={() => toggle(e.id)}>{e.finished ? 'Mark Not Finished' : 'Mark Finished'}</button>
        </div>
      ))}
    </div>
  );
}