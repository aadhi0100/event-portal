import { useState } from 'react';
import { useRouter } from 'next/router';

export default function Login() {
  const [secret, setSecret] = useState('');
  const router = useRouter();

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!secret) return;
    localStorage.setItem('admin_secret', secret);
    router.push('/admin');
  }

  return (
    <div className="container">
      <h1>Admin Login</h1>
      <div className="card">
        <form onSubmit={submit}>
          <label>
            Admin Secret
            <input value={secret} onChange={(e) => setSecret(e.target.value)} />
          </label>
          <button className="button" type="submit">Enter Admin</button>
        </form>
      </div>
    </div>
  );
}