import { useState } from 'react';
import { useRouter } from 'next/router';

export default function RegisterAdmin() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [adminSecret, setAdminSecret] = useState('');
  const [status, setStatus] = useState<string | null>(null);
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setStatus('loading');
    const res = await fetch('/api/admin/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password, adminSecret })
    });
    if (res.ok) {
      setStatus('success');
      router.push('/admin');
    } else {
      setStatus('error');
    }
  }

  return (
    <div className="container">
      <h1>Create Admin</h1>
      <div className="card">
        <form onSubmit={submit}>
          <label>
            Name
            <input required value={name} onChange={(e) => setName(e.target.value)} />
          </label>
          <label>
            Email
            <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          </label>
          <label>
            Password
            <input required type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </label>
          <label>
            Admin Secret (from .env)
            <input required value={adminSecret} onChange={(e) => setAdminSecret(e.target.value)} />
          </label>
          <button className="button" type="submit">Create Admin</button>
          {status === 'error' && <p style={{ color: 'red' }}>Failed to create admin.</p>}
        </form>
      </div>
      <p className="small">Only use this page to create an initial admin in development. In production, protect this flow or create users in a secure admin UI.</p>
    </div>
  );
}