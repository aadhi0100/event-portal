import type { NextApiRequest, NextApiResponse } from 'next';
import prisma from '../../../../lib/prisma';
import { sendMail, renderRegistrationEmail } from '../../../../lib/mailer';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end();
  const id = Number(req.query.id);
  if (isNaN(id)) return res.status(400).json({ error: 'Invalid id' });

  const { name, email } = req.body;
  if (!name || !email) return res.status(400).json({ error: 'Missing name or email' });

  const event = await prisma.event.findUnique({
    where: { id },
    include: { venue: true, timeline: true }
  });
  if (!event) return res.status(404).json({ error: 'Event not found' });

  // Create registration
  const reg = await prisma.registration.create({
    data: { eventId: id, name, email }
  });

  // Prepare and send email
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';
  const { subject, html } = renderRegistrationEmail({
    name,
    event: {
      title: event.title,
      description: event.description,
      startAt: event.startAt.toISOString(),
      endAt: event.endAt.toISOString(),
      timezone: event.timezone,
      slug: event.slug
    },
    venue: { name: event.venue.name, address: event.venue.address },
    timeline: event.timeline.map((t) => ({ title: t.title, startAt: t.startAt.toISOString(), endAt: t.endAt ? t.endAt.toISOString() : undefined, details: t.details })),
    siteUrl
  });

  try {
    await sendMail({ to: email, subject, html });
  } catch (err) {
    console.error('Mail error:', err);
    // do not fail registration on email error
  }

  return res.status(201).json({ ok: true, registrationId: reg.id });
}