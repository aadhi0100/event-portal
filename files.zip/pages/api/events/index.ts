import type { NextApiRequest, NextApiResponse } from 'next';
import prisma from '../../../lib/prisma';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    const events = await prisma.event.findMany({
      orderBy: { startAt: 'asc' },
      select: { id: true, title: true, slug: true, startAt: true, endAt: true, finished: true }
    });
    return res.json(events);
  }

  return res.status(405).end();
}