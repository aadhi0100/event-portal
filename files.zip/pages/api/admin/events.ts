import type { NextApiRequest, NextApiResponse } from 'next';
import prisma from '../../../lib/prisma';
import { getServerSession } from 'next-auth';
import { authOptions } from '../auth/[...nextauth]';

async function isAdmin(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  return session?.user?.role === 'ADMIN';
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (!(await isAdmin(req, res))) return res.status(401).json({ error: 'unauthorized' });

  if (req.method === 'GET') {
    const events = await prisma.event.findMany({
      include: { venue: true },
      orderBy: { startAt: 'desc' }
    });
    return res.json(events);
  }

  return res.status(405).end();
}