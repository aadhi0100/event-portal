import type { NextApiRequest, NextApiResponse } from 'next';
import prisma from '../../../../../lib/prisma';
import { getServerSession } from 'next-auth';
import { authOptions } from '../../../auth/[...nextauth]';

async function isAdmin(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  return session?.user?.role === 'ADMIN';
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (!(await isAdmin(req, res))) return res.status(401).json({ error: 'unauthorized' });

  const id = Number(req.query.id);
  if (isNaN(id)) return res.status(400).json({ error: 'invalid id' });

  if (req.method === 'POST') {
    const ev = await prisma.event.findUnique({ where: { id } });
    if (!ev) return res.status(404).json({ error: 'not found' });

    const updated = await prisma.event.update({
      where: { id },
      data: { finished: !ev.finished }
    });
    return res.json(updated);
  }

  return res.status(405).end();
}