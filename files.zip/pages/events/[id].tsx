import { GetServerSideProps } from 'next';
import prisma from '../../lib/prisma';
import { useState } from 'react';

export const getServerSideProps: GetServerSideProps = async (ctx) => {
  const id = Number(ctx.params?.id);
  const event = await prisma.event.findUnique({
    where: { id },
    include: { venue: true, timeline: true }
  });

  if (!event) {
    return { notFound: true };
  }

  return {
    props: {
      event: {
        id: event.id,
        title: event.title,
        slug: event.slug,
        description: event.description,
        startAt: event.startAt.toISOString(),
        endAt: event.endAt.toISOString(),
        timezone: event.timezone,
        finished: event.finished,
        venue: { name: event.venue.name, address: event.venue.address },
        timeline: event.timeline
          .sort((a, b) => a.order - b.order)
          .map((t) => ({
            title: t.title,
            startAt: t.startAt.toISOString(),
            endAt: t.endAt ? t.endAt.toISOString() : null,
            details: t.details
          }))
      }
    }
  };
};

export default function EventPage({ event }: any) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<string | null>(null);

  async function register(e: React.FormEvent) {
    e.preventDefault();
    setStatus('loading');
    const res = await fetch(`/api/events/${event.id}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email })
    });
    if (res.ok) {
      setStatus('success');
      setName('');
      setEmail('');
    } else {
      setStatus('error');
    }
  }

  return (
    <div className="container">
      <div className="card">
        <h1>{event.title}</h1>
        <p>
          {new Date(event.startAt).toLocaleString()} — {new Date(event.endAt).toLocaleString()} ({event.timezone})
        </p>
        <p><strong>Venue:</strong> {event.venue.name} — {event.venue.address}</p>
        <p><strong>Description:</strong></p>
        <p>{event.description}</p>

        <h3>Timeline</h3>
        <ul>
          {event.timeline.map((t: any, i: number) => (
            <li key={i}>
              <strong>{t.title}</strong> — {new Date(t.startAt).toLocaleString()} {t.endAt ? `to ${new Date(t.endAt).toLocaleString()}` : ''}<br />
              {t.details}
            </li>
          ))}
        </ul>
      </div>

      <div className="card">
        <h3>Register</h3>
        {status === 'success' ? (
          <p>Thanks! Check your email for event details.</p>
        ) : (
          <form onSubmit={register}>
            <label>
              Name
              <input required value={name} onChange={(e) => setName(e.target.value)} />
            </label>
            <label>
              Email
              <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
            </label>
            <button className="button" type="submit">Register</button>
            {status === 'error' && <p style={{ color: 'red' }}>Registration failed. Try again.</p>}
          </form>
        )}
      </div>
    </div>
  );
}