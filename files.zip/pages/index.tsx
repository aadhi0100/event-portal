import Link from 'next/link';
import useSWR from 'swr';

type EventItem = {
  id: number;
  title: string;
  slug: string;
  startAt: string;
  endAt: string;
  finished: boolean;
};

const fetcher = (url: string) => fetch(url).then((r) => r.json());

export default function Home() {
  const { data, error } = useSWR<EventItem[]>('/api/events', fetcher);

  if (error) return <div className="container">Failed to load events</div>;
  if (!data) return <div className="container">Loading...</div>;

  return (
    <div className="container">
      <div className="header">
        <h1>Events</h1>
        <nav>
          <Link href="/admin">Admin</Link>
        </nav>
      </div>

      {data.map((ev) => (
        <div key={ev.id} className="card">
          <h2><Link href={`/events/${ev.id}`}>{ev.title}</Link></h2>
          <p>
            {new Date(ev.startAt).toLocaleString()} — {new Date(ev.endAt).toLocaleString()}
          </p>
          <p className="small">{ev.finished ? 'Finished' : 'Upcoming'}</p>
          <Link href={`/events/${ev.id}`}><button className="button">View</button></Link>
        </div>
      ))}
    </div>
  );
}