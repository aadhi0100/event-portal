import nodemailer from 'nodemailer';

type MailOptions = {
  to: string;
  subject: string;
  html: string;
  text?: string;
};

async function createTransport() {
  const host = process.env.SMTP_HOST;
  const port = process.env.SMTP_PORT ? Number(process.env.SMTP_PORT) : undefined;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (!host || !port || !user || !pass) {
    // fallback to Ethereal (test)
    const testAccount = await nodemailer.createTestAccount();
    return {
      transporter: nodemailer.createTransport({
        host: 'smtp.ethereal.email',
        port: 587,
        auth: {
          user: testAccount.user,
          pass: testAccount.pass
        }
      }),
      previewUrl: true
    };
  }

  return {
    transporter: nodemailer.createTransport({
      host,
      port,
      auth: { user, pass }
    }),
    previewUrl: false
  };
}

export async function sendMail({ to, subject, html, text }: MailOptions) {
  const { transporter, previewUrl } = await createTransport();
  const from = `"Event Portal" <no-reply@example.com>`;
  const info = await transporter.sendMail({ from, to, subject, html, text });

  // If using Ethereal, log preview URL (console)
  if (previewUrl && nodemailer.getTestMessageUrl(info)) {
    console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
  }
  return info;
}

export function renderRegistrationEmail({
  name,
  event,
  venue,
  timeline,
  siteUrl
}: {
  name: string;
  event: { title: string; description: string; startAt: string; endAt: string; timezone: string; slug: string };
  venue: { name: string; address: string };
  timeline: { title: string; startAt: string; endAt?: string; details?: string }[];
  siteUrl: string;
}) {
  const start = new Date(event.startAt).toLocaleString();
  const end = new Date(event.endAt).toLocaleString();

  const timelineHtml = timeline
    .map(
      (t) => `<li><strong>${t.title}</strong> — ${new Date(t.startAt).toLocaleString()}${t.endAt ? ` to ${new Date(t.endAt).toLocaleString()}` : ''}<br/>${t.details ?? ''}</li>`
    )
    .join('');

  const html = `
    <p>Hi ${name},</p>
    <p>Thanks for registering for <strong>${event.title}</strong>.</p>
    <p><strong>When:</strong> ${start} — ${end} (${event.timezone})</p>
    <p><strong>Where:</strong> ${venue.name}, ${venue.address}</p>
    <p><strong>Description:</strong><br/>${event.description}</p>
    <p><strong>Timeline:</strong></p>
    <ul>${timelineHtml}</ul>
    <p>Event page: <a href="${siteUrl}/events/${event.slug}">${siteUrl}/events/${event.slug}</a></p>
    <p>See you there!</p>
  `;

  return { subject: `Registration confirmed — ${event.title}`, html, text: undefined };
}