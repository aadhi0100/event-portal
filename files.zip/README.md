````markdown
# Event Portal

This repository is a starter Event Portal app:
- Public event listing and event details (venue, timeline, description)
- Event registration: registrants receive an email with event details
- Admin UI protected via NextAuth accounts (admins have role "ADMIN")
- Admin register endpoint to create an initial admin (protected by ADMIN_SECRET)
- SQLite by default for local dev, Prisma ORM
- Ethereal (test SMTP) fallback if real SMTP is not configured

Important: this repo scaffold is intended as a starting point. Harden auth and secrets before using in production.

Quickstart (local)
1. Install
   - npm install

2. Copy environment
   - cp .env.example .env
   - Edit .env and set NEXTAUTH_SECRET and ADMIN_SECRET to long random values.

3. Generate Prisma client & migrate
   - npx prisma generate
   - npx prisma migrate dev --name init

4. Seed sample event
   - npm run seed

5. Run dev server
   - npm run dev
   - Open http://localhost:3000

Create an admin account (development)
- Visit http://localhost:3000/admin/register
- Provide the ADMIN_SECRET value from your .env to create the initial admin user.
- After creating the admin, visit http://localhost:3000/admin and sign in.

Email
- If SMTP vars are not set, the app will use Ethereal (test SMTP) and log the preview URL in the server console when a registration email is sent.

Deploying
- The app works on Vercel (Next.js). Set environment variables in the deployment: DATABASE_URL (Postgres recommended in production), NEXTAUTH_SECRET, ADMIN_SECRET, SMTP_* if using real SMTP.

Pushing to GitHub (automated)
- I included a small script `create_and_push.sh` that uses GitHub CLI to create the public repo and push code (see below). You need `gh` installed and authenticated as your account.

If you want, I can:
- Push this repo to GitHub for you (requires permission/gh on my side — I cannot push directly from here). Use the included script to create the repo automatically.
- Add Stripe, ticket PDFs, QR codes, multi-day events, or a proper admin user management UI.
