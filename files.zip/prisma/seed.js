const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  console.log("Seeding database...");

  await prisma.registration.deleteMany();
  await prisma.timelineItem.deleteMany();
  await prisma.event.deleteMany();
  await prisma.venue.deleteMany();
  await prisma.user.deleteMany();

  const venue = await prisma.venue.create({
    data: {
      name: "Grand Hall, Downtown",
      address: "123 Main St, Cityville",
      lat: 37.7749,
      lng: -122.4194
    }
  });

  const event = await prisma.event.create({
    data: {
      title: "Product Launch — Spring 2026",
      slug: "product-launch-spring-2026",
      description: "Join us for an exciting product launch with demos, speakers, and networking.",
      startAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toISOString(),
      endAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7 + 1000 * 60 * 60 * 3).toISOString(),
      timezone: "UTC",
      coverImage: "",
      venueId: venue.id
    }
  });

  await prisma.timelineItem.createMany({
    data: [
      {
        eventId: event.id,
        title: "Registration & Coffee",
        startAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toISOString(),
        endAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7 + 1000 * 60 * 60 * 0.5).toISOString(),
        details: "Check in and grab coffee.",
        order: 0
      },
      {
        eventId: event.id,
        title: "Opening Remarks",
        startAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7 + 1000 * 60 * 60 * 0.5).toISOString(),
        endAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7 + 1000 * 60 * 60 * 1).toISOString(),
        details: "Welcome note and agenda overview.",
        order: 1
      },
      {
        eventId: event.id,
        title: "Live Demo",
        startAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7 + 1000 * 60 * 60 * 1).toISOString(),
        endAt: new Date(Date.now() + 1000 * 60 * 60 * 24 * 7 + 1000 * 60 * 60 * 2).toISOString(),
        details: "Product demo with Q&A.",
        order: 2
      }
    ]
  });

  console.log("Seed completed.");
}

main()
  .catch(e => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });